# PADEL 5IVE Unified v5.4.13 — GitHub upload from iPhone

Files to upload into GitHub repo **root**:
1. `netlify.toml` (the small build/config file)
2. `PADEL5IVE_SITE_PAYLOAD.zip` (keep it zipped; Netlify will unzip at build time)

DO NOT upload the outer `PADEL5IVE_UNIFIED_V5.4.13_GITHUB_IPHONE_2FILES.zip` to GitHub; that outer archive must first be unpacked using Files on iPhone so you can select the two files above.

## iPhone steps
1. Download outer ZIP and open it in iOS **Files**. Tap ZIP once; iOS makes an extracted folder. Open the folder.
2. Go to github.com in Safari, sign in and open your new repo `padel5ive-unified`. If Add file is hidden, choose aA → Request Desktop Website.
3. Repo root → Add file → Upload files → choose your files; upload the two extracted files `netlify.toml` and `PADEL5IVE_SITE_PAYLOAD.zip` (in one batch if supported, otherwise separately). Commit changes to `main`.
4. Verify the GitHub repo **root** contains BOTH, not a parent directory.
5. In Netlify existing project `padel5ive`, connect repo (GitHub continuous deployment) ONLY after you have exported existing browser session backup and confirmed both environment variables are configured (secrets only in Netlify): `PADEL5IVE_UNIFIED_SHARE_PIN` and `PADEL5IVE_SHOWDOWN_SHARE_PIN`.
6. Netlify build settings are defined by root netlify.toml. The build unzips the payload, installs dependencies and verifies output. Publish `public/`, functions `netlify/functions`.
7. Check deploy logs for SUCCESS and 2 Functions, verify Home, both modes, and actual Share Results URLs.

## Notes
- Connected GitHub `main` commits can auto-deploy directly to production, so confirm you are connecting the intended existing Netlify project and have a last-good deploy to rollback.
- Existing site's browser localStorage and remote Netlify Blobs ARE NOT contained in this source package.
- Backend API integration must be tested live before declaring master lock. Do not put secret PINs in repo/files.
- This is a bootstrap delivery wrapper. The **underlying application files** come unmodified from the v5.4.13 release ZIP; only the deploy method changes.
